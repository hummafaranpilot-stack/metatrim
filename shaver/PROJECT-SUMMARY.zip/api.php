<?php
/**
 * Affiliate Shaving API
 *
 * REST API endpoints for managing shaving sessions, tracking, and analytics
 */

require_once 'config.php';

$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'];

// CORS headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($method === 'OPTIONS') {
    exit(0);
}

// Get action from GET or POST body
$request = isset($_GET['action']) ? $_GET['action'] : '';
if (empty($request) && $method === 'POST') {
    $postData = json_decode(file_get_contents('php://input'), true);
    $request = $postData['action'] ?? '';
}

try {
    switch ($request) {
        case 'get_sessions':
        case 'getSessions':
            getSessions($pdo);
            break;

        case 'create_session':
        case 'createSession':
            createSession($pdo);
            break;

        case 'stop_session':
        case 'stopSession':
            stopSession($pdo);
            break;

        case 'track_visit':
        case 'trackVisit':
            trackVisit($pdo);
            break;

        case 'track_click':
        case 'trackClick':
            trackClick($pdo);
            break;

        case 'get_history':
        case 'getHistory':
            getHistory($pdo);
            break;

        case 'delete_history':
        case 'deleteHistory':
            deleteHistory($pdo);
            break;

        // Analytics endpoints
        case 'log_traffic':
        case 'logTraffic':
            logTraffic($pdo);
            break;

        case 'get_analytics':
        case 'getAnalytics':
            getAnalytics($pdo);
            break;

        case 'get_traffic_log':
        case 'getTrafficLog':
            getTrafficLog($pdo);
            break;

        // NEW: Behavior tracking endpoints
        case 'log_behavior_event':
        case 'logBehaviorEvent':
            logBehaviorEvent($pdo);
            break;

        case 'update_session_metrics':
        case 'updateSessionMetrics':
            updateSessionMetrics($pdo);
            break;

        case 'get_behavior_details':
        case 'getBehaviorDetails':
            getBehaviorDetails($pdo);
            break;

        default:
            http_response_code(404);
            echo json_encode(['error' => 'Invalid endpoint']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// Get all active sessions
function getSessions($pdo) {
    $stmt = $pdo->query("
        SELECT
            s.*,
            COALESCE(SUM(CASE WHEN t.event_type = 'visit' THEN 1 ELSE 0 END), 0) as visits,
            COALESCE(SUM(CASE WHEN t.event_type = 'click' THEN 1 ELSE 0 END), 0) as clicks
        FROM shaving_sessions s
        LEFT JOIN shaving_tracking t ON s.id = t.session_id
        WHERE s.active = 1
        GROUP BY s.id
        ORDER BY s.start_time DESC
    ");

    $sessions = $stmt->fetchAll();

    $formattedSessions = array_map(function($session) {
        $startTimestamp = strtotime($session['start_time']) * 1000;

        return [
            'id' => $session['id'],
            'affId' => $session['aff_id'],
            'subId' => $session['sub_id'],
            'replaceMode' => (bool)$session['replace_mode'],
            'replaceAffId' => $session['replace_aff_id'],
            'replaceSubId' => $session['replace_sub_id'],
            'startTime' => $startTimestamp,
            'active' => (bool)$session['active'],
            'visits' => (int)$session['visits'],
            'clicks' => (int)$session['clicks']
        ];
    }, $sessions);

    echo json_encode([
        'success' => true,
        'data' => $formattedSessions,
        'sessions' => $formattedSessions  // For dashboard compatibility
    ]);
}

// Create new shaving session
function createSession($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $id = $data['id'] ?? uniqid('session_', true);
    $affId = $data['aff_id'] ?? $data['affId'] ?? '';
    $subId = $data['sub_id'] ?? $data['subId'] ?? '';
    $replaceMode = $data['replace_mode'] ?? $data['replaceMode'] ?? false;
    $replaceAffId = $data['replace_aff_id'] ?? $data['replaceAffId'] ?? '';
    $replaceSubId = $data['replace_sub_id'] ?? $data['replaceSubId'] ?? '';
    $startTime = $data['start_time'] ?? $data['startTime'] ?? date('Y-m-d H:i:s');

    if (empty($affId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Affiliate ID is required']);
        return;
    }

    $stmt = $pdo->prepare("SELECT id FROM shaving_sessions WHERE aff_id = ? AND sub_id = ? AND active = 1");
    $stmt->execute([$affId, $subId]);
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Session already exists for this affiliate ID']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO shaving_sessions (id, aff_id, sub_id, replace_mode, replace_aff_id, replace_sub_id, start_time)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $id,
        $affId,
        $subId,
        $replaceMode ? 1 : 0,
        $replaceAffId,
        $replaceSubId,
        $startTime
    ]);

    echo json_encode([
        'success' => true,
        'sessionId' => $id
    ]);
}

// Stop a shaving session
function stopSession($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    $sessionId = $data['session_id'] ?? $data['sessionId'] ?? '';

    if (empty($sessionId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Session ID is required']);
        return;
    }

    $stmt = $pdo->prepare("SELECT * FROM shaving_sessions WHERE id = ?");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch();

    if (!$session) {
        http_response_code(404);
        echo json_encode(['error' => 'Session not found']);
        return;
    }

    $stmt = $pdo->prepare("
        SELECT
            SUM(CASE WHEN event_type = 'visit' THEN 1 ELSE 0 END) as visits,
            SUM(CASE WHEN event_type = 'click' THEN 1 ELSE 0 END) as clicks
        FROM shaving_tracking
        WHERE session_id = ?
    ");
    $stmt->execute([$sessionId]);
    $stats = $stmt->fetch();

    $stopTime = date('Y-m-d H:i:s');
    $startTime = strtotime($session['start_time']);
    $duration = time() - $startTime;

    $stmt = $pdo->prepare("
        INSERT INTO shaving_history
        (session_id, aff_id, sub_id, replace_mode, replace_aff_id, replace_sub_id, start_time, stop_time, total_visits, total_clicks, duration)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $sessionId,
        $session['aff_id'],
        $session['sub_id'],
        $session['replace_mode'],
        $session['replace_aff_id'],
        $session['replace_sub_id'],
        $session['start_time'],
        $stopTime,
        $stats['visits'] ?? 0,
        $stats['clicks'] ?? 0,
        $duration
    ]);

    $stmt = $pdo->prepare("UPDATE shaving_sessions SET active = 0 WHERE id = ?");
    $stmt->execute([$sessionId]);

    echo json_encode(['success' => true]);
}

// Track a visit (shaved)
function trackVisit($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $sessionId = $data['session_id'] ?? $data['sessionId'] ?? '';
    $affId = $data['aff_id'] ?? $data['affId'] ?? '';
    $subId = $data['sub_id'] ?? $data['subId'] ?? '';
    $page = $data['page'] ?? '';
    $referrer = $data['referrer'] ?? '';

    $stmt = $pdo->prepare("
        INSERT INTO shaving_tracking (session_id, aff_id, sub_id, event_type, page, referrer, timestamp)
        VALUES (?, ?, ?, 'visit', ?, ?, NOW())
    ");

    $stmt->execute([$sessionId, $affId, $subId, $page, $referrer]);

    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM shaving_tracking WHERE session_id = ? AND event_type = 'visit'");
    $stmt->execute([$sessionId]);
    $result = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'totalVisits' => $result['total']
    ]);
}

// Track a click (shaved)
function trackClick($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $sessionId = $data['session_id'] ?? $data['sessionId'] ?? '';
    $affId = $data['aff_id'] ?? $data['affId'] ?? '';
    $subId = $data['sub_id'] ?? $data['subId'] ?? '';
    $page = $data['page'] ?? '';

    $stmt = $pdo->prepare("
        INSERT INTO shaving_tracking (session_id, aff_id, sub_id, event_type, page, timestamp)
        VALUES (?, ?, ?, 'click', ?, NOW())
    ");

    $stmt->execute([$sessionId, $affId, $subId, $page]);

    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM shaving_tracking WHERE session_id = ? AND event_type = 'click'");
    $stmt->execute([$sessionId]);
    $result = $stmt->fetch();

    echo json_encode([
        'success' => true,
        'totalClicks' => $result['total']
    ]);
}

// Get session history
function getHistory($pdo) {
    $stmt = $pdo->query("
        SELECT * FROM shaving_history
        ORDER BY stop_time DESC
        LIMIT 100
    ");

    $history = $stmt->fetchAll();

    $formattedHistory = array_map(function($item) {
        $startTimestamp = strtotime($item['start_time']) * 1000;
        $stopTimestamp = strtotime($item['stop_time']) * 1000;

        return [
            'id' => $item['session_id'],
            'affId' => $item['aff_id'],
            'subId' => $item['sub_id'],
            'replaceMode' => (bool)$item['replace_mode'],
            'replaceAffId' => $item['replace_aff_id'],
            'replaceSubId' => $item['replace_sub_id'],
            'startTime' => $startTimestamp,
            'stopTime' => $stopTimestamp,
            'visits' => (int)$item['total_visits'],
            'clicks' => (int)$item['total_clicks'],
            'duration' => (int)$item['duration']
        ];
    }, $history);

    echo json_encode([
        'success' => true,
        'data' => $formattedHistory
    ]);
}

// Delete history entry
function deleteHistory($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);
    $historyId = $data['session_id'] ?? $data['historyId'] ?? '';

    if (empty($historyId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Session ID is required']);
        return;
    }

    $stmt = $pdo->prepare("DELETE FROM shaving_history WHERE session_id = ?");
    $stmt->execute([$historyId]);

    echo json_encode(['success' => true]);
}

// ================================================================
// NEW: ANALYTICS FUNCTIONS
// ================================================================

// Log ALL affiliate traffic
function logTraffic($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $affId = $data['aff_id'] ?? '';
    $subId = $data['sub_id'] ?? '';
    $pageUrl = $data['page_url'] ?? '';
    $referrer = $data['referrer'] ?? '';
    $userAgent = $data['user_agent'] ?? '';
    $wasShaved = $data['was_shaved'] ?? false;
    $shavingSessionId = $data['shaving_session_id'] ?? null;

    // NEW: Behavior tracking fields
    $sessionUUID = $data['session_uuid'] ?? null;
    $screenWidth = $data['screen_width'] ?? null;
    $screenHeight = $data['screen_height'] ?? null;
    $viewportWidth = $data['viewport_width'] ?? null;
    $viewportHeight = $data['viewport_height'] ?? null;

    if (empty($affId)) {
        echo json_encode(['success' => true, 'skipped' => true]);
        return;
    }

    // Get visitor IP
    $ip = getClientIP();

    // Parse browser and device from user agent
    $browserInfo = parseBrowserInfo($userAgent);

    // Get country from IP (using free API)
    $geoInfo = getGeoInfo($ip);

    $stmt = $pdo->prepare("
        INSERT INTO affiliate_traffic
        (aff_id, sub_id, page_url, referrer, user_agent, browser, device, ip_address, country, country_code,
         was_shaved, shaving_session_id, session_uuid, screen_width, screen_height, viewport_width, viewport_height)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $affId,
        $subId,
        $pageUrl,
        $referrer,
        $userAgent,
        $browserInfo['browser'],
        $browserInfo['device'],
        $ip,
        $geoInfo['country'],
        $geoInfo['countryCode'],
        $wasShaved ? 1 : 0,
        $shavingSessionId,
        $sessionUUID,
        $screenWidth,
        $screenHeight,
        $viewportWidth,
        $viewportHeight
    ]);

    $trafficId = $pdo->lastInsertId();

    echo json_encode([
        'success' => true,
        'traffic_id' => $trafficId  // CRITICAL: Return traffic_id for behavior tracking
    ]);
}

// Get analytics data
function getAnalytics($pdo) {
    $period = $_GET['period'] ?? 'today';

    // Calculate time filter
    switch ($period) {
        case 'today':
            // Today in PKT (Pakistan Time = UTC + 5)
            // Get current time in PKT
            $now = new DateTime('now', new DateTimeZone('Asia/Karachi'));
            $start = clone $now;
            $start->setTime(0, 0, 0);
            $end = clone $now;
            $end->setTime(23, 59, 59);

            // Convert to UTC for MySQL (which stores in UTC)
            $start->setTimezone(new DateTimeZone('UTC'));
            $end->setTimezone(new DateTimeZone('UTC'));

            $startStr = $start->format('Y-m-d H:i:s');
            $endStr = $end->format('Y-m-d H:i:s');
            $timeFilter = "timestamp >= '$startStr' AND timestamp <= '$endStr'";
            break;

        case 'yesterday':
            // Yesterday in PKT
            $now = new DateTime('now', new DateTimeZone('Asia/Karachi'));
            $yesterday = clone $now;
            $yesterday->modify('-1 day');
            $start = clone $yesterday;
            $start->setTime(0, 0, 0);
            $end = clone $yesterday;
            $end->setTime(23, 59, 59);

            // Convert to UTC
            $start->setTimezone(new DateTimeZone('UTC'));
            $end->setTimezone(new DateTimeZone('UTC'));

            $startStr = $start->format('Y-m-d H:i:s');
            $endStr = $end->format('Y-m-d H:i:s');
            $timeFilter = "timestamp >= '$startStr' AND timestamp <= '$endStr'";
            break;

        case 'thisweek':
            // This week (Monday to Sunday) in PKT
            $now = new DateTime('now', new DateTimeZone('Asia/Karachi'));
            $dayOfWeek = $now->format('N'); // 1 (Monday) to 7 (Sunday)

            // Get Monday of this week
            $monday = clone $now;
            $monday->modify('-' . ($dayOfWeek - 1) . ' days');
            $monday->setTime(0, 0, 0);

            // Get Sunday of this week
            $sunday = clone $monday;
            $sunday->modify('+6 days');
            $sunday->setTime(23, 59, 59);

            // Convert to UTC
            $monday->setTimezone(new DateTimeZone('UTC'));
            $sunday->setTimezone(new DateTimeZone('UTC'));

            $startStr = $monday->format('Y-m-d H:i:s');
            $endStr = $sunday->format('Y-m-d H:i:s');
            $timeFilter = "timestamp >= '$startStr' AND timestamp <= '$endStr'";
            break;

        case 'all':
            $timeFilter = "1=1";
            break;

        default:
            // Default to today
            $now = new DateTime('now', new DateTimeZone('Asia/Karachi'));
            $start = clone $now;
            $start->setTime(0, 0, 0);
            $end = clone $now;
            $end->setTime(23, 59, 59);
            $start->setTimezone(new DateTimeZone('UTC'));
            $end->setTimezone(new DateTimeZone('UTC'));
            $startStr = $start->format('Y-m-d H:i:s');
            $endStr = $end->format('Y-m-d H:i:s');
            $timeFilter = "timestamp >= '$startStr' AND timestamp <= '$endStr'";
    }

    // Total stats
    $stmt = $pdo->query("
        SELECT
            COUNT(*) as total_visits,
            COUNT(DISTINCT aff_id) as unique_affiliates,
            SUM(was_shaved) as shaved_visits,
            COUNT(DISTINCT ip_address) as unique_visitors
        FROM affiliate_traffic
        WHERE $timeFilter
    ");
    $totals = $stmt->fetch();

    // Top affiliates
    $stmt = $pdo->query("
        SELECT
            aff_id,
            COUNT(*) as visits,
            SUM(was_shaved) as shaved,
            COUNT(DISTINCT ip_address) as unique_ips
        FROM affiliate_traffic
        WHERE $timeFilter
        GROUP BY aff_id
        ORDER BY visits DESC
        LIMIT 20
    ");
    $topAffiliates = $stmt->fetchAll();

    // Browser breakdown
    $stmt = $pdo->query("
        SELECT browser, COUNT(*) as count
        FROM affiliate_traffic
        WHERE $timeFilter AND browser IS NOT NULL AND browser != ''
        GROUP BY browser
        ORDER BY count DESC
        LIMIT 10
    ");
    $browsers = $stmt->fetchAll();

    // Device breakdown
    $stmt = $pdo->query("
        SELECT device, COUNT(*) as count
        FROM affiliate_traffic
        WHERE $timeFilter AND device IS NOT NULL AND device != ''
        GROUP BY device
        ORDER BY count DESC
    ");
    $devices = $stmt->fetchAll();

    // Country breakdown
    $stmt = $pdo->query("
        SELECT country, country_code, COUNT(*) as count
        FROM affiliate_traffic
        WHERE $timeFilter AND country IS NOT NULL AND country != ''
        GROUP BY country, country_code
        ORDER BY count DESC
        LIMIT 15
    ");
    $countries = $stmt->fetchAll();

    // Top referrers
    $stmt = $pdo->query("
        SELECT
            CASE
                WHEN referrer = '' OR referrer IS NULL OR referrer = 'direct' THEN 'Direct'
                ELSE SUBSTRING_INDEX(SUBSTRING_INDEX(REPLACE(REPLACE(referrer, 'https://', ''), 'http://', ''), '/', 1), '?', 1)
            END as source,
            COUNT(*) as count
        FROM affiliate_traffic
        WHERE $timeFilter
        GROUP BY source
        ORDER BY count DESC
        LIMIT 10
    ");
    $referrers = $stmt->fetchAll();

    // Hourly traffic (last 24 hours)
    $stmt = $pdo->query("
        SELECT
            DATE_FORMAT(timestamp, '%Y-%m-%d %H:00') as hour,
            COUNT(*) as visits
        FROM affiliate_traffic
        WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        GROUP BY hour
        ORDER BY hour ASC
    ");
    $hourlyTraffic = $stmt->fetchAll();

    // Top landing pages - show exact path structure
    $stmt = $pdo->query("
        SELECT
            REPLACE(
                REPLACE(
                    REPLACE(
                        SUBSTRING_INDEX(SUBSTRING_INDEX(page_url, '?', 1), '/', -4),
                        '/index.html', ''
                    ),
                    '.html', ''
                ),
                '.php', ''
            ) as landing_page,
            COUNT(*) as count
        FROM affiliate_traffic
        WHERE $timeFilter AND page_url IS NOT NULL AND page_url != ''
        GROUP BY landing_page
        ORDER BY count DESC
        LIMIT 10
    ");
    $landingPages = $stmt->fetchAll();

    $analyticsData = [
        'totals' => [
            'totalVisits' => (int)$totals['total_visits'],
            'uniqueAffiliates' => (int)$totals['unique_affiliates'],
            'shavedVisits' => (int)$totals['shaved_visits'],
            'uniqueVisitors' => (int)$totals['unique_visitors']
        ],
        'topAffiliates' => $topAffiliates,
        'browsers' => $browsers,
        'devices' => $devices,
        'countries' => $countries,
        'referrers' => $referrers,
        'landingPages' => $landingPages,
        'hourlyTraffic' => $hourlyTraffic
    ];

    // Flattened version for dashboard compatibility
    $dashboardStats = [
        'totalVisits' => (int)$totals['total_visits'],
        'todayVisits' => (int)$totals['total_visits'],  // TODO: Calculate actual today visits
        'shavedVisits' => (int)$totals['shaved_visits'],
        'uniqueVisitors' => (int)$totals['unique_visitors'],
        'checkoutRate' => 0,  // TODO: Calculate checkout rate
        'uniqueAffiliates' => (int)$totals['unique_affiliates']
    ];

    echo json_encode([
        'success' => true,
        'data' => $analyticsData,
        'stats' => $dashboardStats  // Flattened for dashboard compatibility
    ]);
}

// Get recent traffic log
function getTrafficLog($pdo) {
    // Get POST data if available
    $postData = json_decode(file_get_contents('php://input'), true);

    $limit = $postData['limit'] ?? $_GET['limit'] ?? 50;
    $limit = min((int)$limit, 200);
    $affId = $postData['aff_id'] ?? $_GET['aff_id'] ?? '';

    $sql = "SELECT * FROM affiliate_traffic";
    $params = [];

    if (!empty($affId)) {
        $sql .= " WHERE aff_id = ?";
        $params[] = $affId;
    }

    $sql .= " ORDER BY timestamp DESC LIMIT $limit";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $traffic = $stmt->fetchAll();

    $formatted = array_map(function($item) {
        return [
            'id' => $item['id'],
            'affId' => $item['aff_id'],
            'subId' => $item['sub_id'],
            'pageUrl' => $item['page_url'],
            'referrer' => $item['referrer'],
            'browser' => $item['browser'],
            'device' => $item['device'],
            'ip' => $item['ip_address'],
            'country' => $item['country'],
            'countryCode' => $item['country_code'],
            'wasShaved' => (bool)$item['was_shaved'],
            'timestamp' => $item['timestamp'],
            // NEW: Behavior metrics
            'sessionDuration' => $item['session_duration'],
            'maxScrollDepth' => $item['max_scroll_depth'],
            'totalClicks' => $item['total_clicks'],
            'reachedCheckout' => (bool)$item['reached_checkout'],
            'timeToFirstClick' => $item['time_to_first_click'],
            'timeToCheckout' => $item['time_to_checkout'],
            'bounce' => (bool)$item['bounce']
        ];
    }, $traffic);

    echo json_encode([
        'success' => true,
        'data' => $formatted,
        'traffic' => $formatted  // For dashboard compatibility
    ]);
}

// ================================================================
// NEW: BEHAVIOR TRACKING ENDPOINTS
// ================================================================

// Log individual behavior event
function logBehaviorEvent($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $trafficId = $data['traffic_id'] ?? null;
    $sessionUUID = $data['session_uuid'] ?? null;
    $eventType = $data['event_type'] ?? '';
    $eventData = $data['event_data'] ?? [];
    $timestamp = $data['timestamp'] ?? date('Y-m-d H:i:s');

    if (empty($trafficId) || empty($sessionUUID) || empty($eventType)) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        return;
    }

    // Validate event type
    $validEvents = ['page_view', 'scroll', 'click', 'hover', 'checkout_reached', 'tab_hidden', 'tab_visible'];
    if (!in_array($eventType, $validEvents)) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid event type']);
        return;
    }

    $stmt = $pdo->prepare("
        INSERT INTO user_behavior_events
        (traffic_id, session_uuid, event_type, event_data, timestamp)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $trafficId,
        $sessionUUID,
        $eventType,
        json_encode($eventData),
        $timestamp
    ]);

    echo json_encode(['success' => true, 'event_id' => $pdo->lastInsertId()]);
}

// Update session-level metrics
function updateSessionMetrics($pdo) {
    $data = json_decode(file_get_contents('php://input'), true);

    $trafficId = $data['traffic_id'] ?? null;
    $sessionDuration = $data['session_duration'] ?? null;
    $maxScrollDepth = $data['max_scroll_depth'] ?? 0;
    $totalClicks = $data['total_clicks'] ?? 0;
    $reachedCheckout = $data['reached_checkout'] ?? 0;
    $checkoutUrl = $data['checkout_url'] ?? null;
    $timeToFirstClick = $data['time_to_first_click'] ?? null;
    $timeToCheckout = $data['time_to_checkout'] ?? null;
    $screenWidth = $data['screen_width'] ?? null;
    $screenHeight = $data['screen_height'] ?? null;
    $viewportWidth = $data['viewport_width'] ?? null;
    $viewportHeight = $data['viewport_height'] ?? null;
    $pageLoadTime = $data['page_load_time'] ?? null;
    $bounce = $data['bounce'] ?? 1;

    if (empty($trafficId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing traffic_id']);
        return;
    }

    $stmt = $pdo->prepare("
        UPDATE affiliate_traffic
        SET session_duration = ?,
            max_scroll_depth = ?,
            total_clicks = ?,
            reached_checkout = ?,
            checkout_url = ?,
            time_to_first_click = ?,
            time_to_checkout = ?,
            screen_width = ?,
            screen_height = ?,
            viewport_width = ?,
            viewport_height = ?,
            page_load_time = ?,
            bounce = ?
        WHERE id = ?
    ");

    $stmt->execute([
        $sessionDuration,
        $maxScrollDepth,
        $totalClicks,
        $reachedCheckout,
        $checkoutUrl,
        $timeToFirstClick,
        $timeToCheckout,
        $screenWidth,
        $screenHeight,
        $viewportWidth,
        $viewportHeight,
        $pageLoadTime,
        $bounce,
        $trafficId
    ]);

    echo json_encode(['success' => true]);
}

// Get detailed behavior events for a traffic session
function getBehaviorDetails($pdo) {
    $trafficId = $_GET['traffic_id'] ?? null;

    if (empty($trafficId)) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing traffic_id']);
        return;
    }

    // Get session info
    $stmt = $pdo->prepare("SELECT * FROM affiliate_traffic WHERE id = ?");
    $stmt->execute([$trafficId]);
    $sessionInfo = $stmt->fetch();

    if (!$sessionInfo) {
        http_response_code(404);
        echo json_encode(['error' => 'Traffic session not found']);
        return;
    }

    // Get all behavior events
    $stmt = $pdo->prepare("
        SELECT event_type, event_data, timestamp
        FROM user_behavior_events
        WHERE traffic_id = ?
        ORDER BY timestamp ASC
    ");
    $stmt->execute([$trafficId]);
    $events = $stmt->fetchAll();

    // Parse event_data JSON
    foreach ($events as &$event) {
        $event['event_data'] = json_decode($event['event_data'], true);
    }

    echo json_encode([
        'success' => true,
        'session' => [
            'traffic_id' => $sessionInfo['id'],
            'aff_id' => $sessionInfo['aff_id'],
            'sub_id' => $sessionInfo['sub_id'],
            'ip_address' => $sessionInfo['ip_address'],
            'browser' => $sessionInfo['browser'],
            'device' => $sessionInfo['device'],
            'country' => $sessionInfo['country'],
            'timestamp' => $sessionInfo['timestamp'],
            'session_duration' => $sessionInfo['session_duration'],
            'max_scroll_depth' => $sessionInfo['max_scroll_depth'],
            'total_clicks' => $sessionInfo['total_clicks'],
            'reached_checkout' => (bool)$sessionInfo['reached_checkout'],
            'checkout_url' => $sessionInfo['checkout_url'],
            'time_to_first_click' => $sessionInfo['time_to_first_click'],
            'time_to_checkout' => $sessionInfo['time_to_checkout'],
            'bounce' => (bool)$sessionInfo['bounce']
        ],
        'events' => $events
    ]);
}

// ================================================================
// HELPER FUNCTIONS
// ================================================================

// Helper: Get client IP
function getClientIP() {
    $ip = '';
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    return trim($ip);
}

// Helper: Parse browser info from user agent
function parseBrowserInfo($userAgent) {
    $browser = 'Unknown';
    $device = 'Desktop';

    // Detect browser
    if (preg_match('/MSIE|Trident/i', $userAgent)) {
        $browser = 'IE';
    } elseif (preg_match('/Edg/i', $userAgent)) {
        $browser = 'Edge';
    } elseif (preg_match('/Firefox/i', $userAgent)) {
        $browser = 'Firefox';
    } elseif (preg_match('/Chrome/i', $userAgent) && !preg_match('/Edg/i', $userAgent)) {
        $browser = 'Chrome';
    } elseif (preg_match('/Safari/i', $userAgent) && !preg_match('/Chrome/i', $userAgent)) {
        $browser = 'Safari';
    } elseif (preg_match('/Opera|OPR/i', $userAgent)) {
        $browser = 'Opera';
    }

    // Detect device
    if (preg_match('/Mobile|Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i', $userAgent)) {
        if (preg_match('/iPad|Tablet/i', $userAgent)) {
            $device = 'Tablet';
        } else {
            $device = 'Mobile';
        }
    }

    return ['browser' => $browser, 'device' => $device];
}

// Helper: Get geo info from IP
function getGeoInfo($ip) {
    $country = 'Unknown';
    $countryCode = 'XX';

    // Skip for local IPs
    if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0 || strpos($ip, '10.') === 0) {
        return ['country' => 'Local', 'countryCode' => 'LO'];
    }

    // Use free IP-API (no key required, 45 requests/minute)
    $url = "http://ip-api.com/json/{$ip}?fields=country,countryCode";

    $context = stream_context_create([
        'http' => [
            'timeout' => 2,
            'ignore_errors' => true
        ]
    ]);

    $response = @file_get_contents($url, false, $context);

    if ($response) {
        $data = json_decode($response, true);
        if ($data && isset($data['country'])) {
            $country = $data['country'];
            $countryCode = $data['countryCode'] ?? 'XX';
        }
    }

    return ['country' => $country, 'countryCode' => $countryCode];
}
?>
